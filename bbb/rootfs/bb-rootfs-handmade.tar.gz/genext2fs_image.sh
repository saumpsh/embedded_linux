#!/bin/sh

genext2fs -b 16384 -d rootfs -D device-table.txt -U rootfs.ext2
